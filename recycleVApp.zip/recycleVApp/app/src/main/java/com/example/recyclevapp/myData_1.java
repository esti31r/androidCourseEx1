package com.example.recycleview;

public class myData {

  static String[] nameArray = {"arthur", "buster", "francine", "muffy", "brain", "binky", "ratburn", "MsRead", "MrRead", "DW"};

  static String[] versionArray = { 
    "Glasses, aardvark, loves books",
    "Goofy, food lover, Arthur's best friend", 
    "Monkey, talented athlete and singer",
    "Wealthy bear, likes fashion",
    "Smart bear, into science and math", 
    "Tough bulldog with soft side",
    "Arthur and friends' teacher, rat",
    "Arthur's kind mother, ape", 
    "Arthur's overworked father, ape",  
    "Arthur's cheeky little sister, ape"    
  };

  static Integer[] drawableArray = {
    R.drawable.arthur,  
    R.drawable.buster,
    R.drawable.francine,
    R.drawable.muffy,
    R.drawable.brain,
    R.drawable.binky,  
    R.drawable.ratburn,
    R.drawable.mrsread,
    R.drawable.mrread,
    R.drawable.dw
  };
   
  static Integer[] id_ = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};  

}